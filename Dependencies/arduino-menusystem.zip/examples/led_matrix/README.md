This example depends on the ht1632c library which can be found at
https://github.com/wildstray/ht1632c.

The patch in the folder with this example needs to be applied to the above
library for it to work.
